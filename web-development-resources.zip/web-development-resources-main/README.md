# Awesome Web Development Resources ![Awesome][awesome-badge]

This is an awesome project about Web Development resources. ⚡

Resources are added frequently! ⚡

Enjoy! :)

If you like this repo, be sure to ⭐ it.

Please read [`contributing guidelines`](./CONTRIBUTING.md) before submitting new resources.

Initially created by [Marko](https://markodenic.com) at [Web Development Resources](https://markodenic.com/free-web-development-resources/).


Similar amazing projects: [Public APIs](https://publicapis.dev) - [Dev Resources](https://devresourc.es)

[awesome-badge]: https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg
