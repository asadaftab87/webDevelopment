# Thank you! ❤️

Thank you for contributing to our awesome resources.

## Guidelines

- **One item** per Pull Request.

- Add a link of the resource in PR comment section.
  
- Pull request should include a link to the resource and a short description.

- The resource **must** be completely free or to have a free tier.

- If a category consists of 10 or more resources, don't submit any new resources to this category. Consider contributing to other categories instead.

## Thank you! ❤️
